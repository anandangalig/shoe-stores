-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Sep 30, 2016 at 11:37 PM
-- Server version: 5.5.42
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 1, 342),
(2, 2, 343),
(3, 3, 343),
(4, 4, 352),
(5, 5, 353),
(6, 6, 353),
(7, 15, 354),
(8, 16, 355),
(9, 16, 356),
(10, 17, 365),
(11, 18, 366),
(12, 19, 366),
(13, 28, 367),
(14, 29, 368),
(15, 29, 369),
(16, 30, 378),
(17, 31, 379),
(18, 32, 379),
(19, 41, 380),
(20, 42, 381),
(21, 42, 382),
(22, 43, 391),
(23, 44, 392),
(24, 45, 392),
(25, 54, 393),
(26, 55, 394),
(27, 55, 395),
(28, 56, 404),
(29, 57, 405),
(30, 58, 405),
(31, 67, 406),
(32, 68, 407),
(33, 68, 408),
(34, 69, 417),
(35, 70, 418),
(36, 71, 418),
(37, 80, 419),
(38, 81, 420),
(39, 81, 421),
(40, 82, 430),
(41, 83, 431),
(42, 84, 431),
(43, 93, 432),
(44, 94, 433),
(45, 94, 434),
(46, 95, 443),
(47, 96, 444),
(48, 97, 444),
(49, 9, 1),
(50, 10, 2),
(51, 10, 3),
(52, 13, 12),
(53, 14, 13),
(54, 15, 13),
(55, 24, 16),
(56, 25, 17),
(57, 25, 18),
(58, 28, 19),
(59, 28, 20),
(60, 29, 29),
(61, 30, 30),
(62, 31, 30),
(63, 40, 33),
(64, 41, 34),
(65, 41, 35),
(67, 44, 37),
(68, 45, 46),
(69, 46, 47),
(70, 47, 47),
(71, 56, 50),
(72, 57, 51),
(73, 57, 52),
(75, 60, 54),
(76, 61, 63),
(77, 62, 64),
(78, 63, 64),
(80, 65, 67),
(81, 74, 68),
(82, 75, 69),
(83, 75, 70),
(85, 78, 72),
(86, 79, 81),
(87, 80, 82),
(88, 81, 82),
(90, 83, 85);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=86;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
